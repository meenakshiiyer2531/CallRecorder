# CallRecorderApp
 It records the call and then plays it.
 - When a user calls or receives a call , the call gets recorded 
- Both parties will be audible on the recording
- no system prompts plays
